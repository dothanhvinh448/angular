export class User{
    userid=Date.now();
    username:string=""
    password:string=""
    email:string=""
}