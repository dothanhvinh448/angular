export class product{
   id:number=0;
   name:String="abcc";
   dongia:number=1;
   hinh:String="";
   soluong:number=1
}
