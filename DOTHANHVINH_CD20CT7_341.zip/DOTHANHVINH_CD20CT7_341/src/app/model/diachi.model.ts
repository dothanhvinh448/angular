export class diachi{
    date:Date=new Date()
    fullname:string="";
    address:string="";
    sdt:string=""
    ghichu:string=""
    method:string=""
    ngaymua:string=this.date.getDate()+"/"+(this.date.getMonth()+1)+"/"+this.date.getFullYear()

}