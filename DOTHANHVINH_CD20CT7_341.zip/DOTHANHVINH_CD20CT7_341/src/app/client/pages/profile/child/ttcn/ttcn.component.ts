import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ttcn',
  templateUrl: './ttcn.component.html',
  styleUrls: ['./ttcn.component.scss']
})
export class TtcnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
